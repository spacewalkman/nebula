namespace py typedef_test.includer

include "included.thrift"

typedef included.Foo InclFoo
typedef included.Pod InclPod
typedef included.Pods InclPods
typedef included.Beep InclBeep
typedef included.BeepAlso InclBeepAlso
typedef included.Int64 InclInt64
