namespace cpp2 test_cpp2.cpp_reflection

struct dep_D_struct {
  1: i32 i_d
}
