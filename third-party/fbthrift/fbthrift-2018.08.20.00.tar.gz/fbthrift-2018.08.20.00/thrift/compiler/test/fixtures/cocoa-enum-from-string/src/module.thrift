namespace cocoa example

enum Example {
  caseA = 1
  caseB = 2
} (cocoa.enum_conversion)
