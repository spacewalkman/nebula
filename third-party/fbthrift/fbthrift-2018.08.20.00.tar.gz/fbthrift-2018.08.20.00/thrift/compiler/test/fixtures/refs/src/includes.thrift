namespace cpp cpp1
namespace cpp2 cpp2

struct Included {
  1: i16 some_val
}
