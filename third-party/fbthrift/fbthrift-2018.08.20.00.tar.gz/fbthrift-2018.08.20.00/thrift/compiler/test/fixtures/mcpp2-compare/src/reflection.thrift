struct ReflectionStruct {
  1: i32 fieldA = 5
}
